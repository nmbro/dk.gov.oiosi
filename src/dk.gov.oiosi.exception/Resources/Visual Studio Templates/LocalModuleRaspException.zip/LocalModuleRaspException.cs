using System;
using System.Collections.Generic;
using System.Text;
using System.Resources;
using Oiosi.Rasp.ExceptionHandling;

namespace $rootnamespace$
{
    public class $safeitemname$ : $parentexception$ {
        public $safeitemname$() : base() { }
        public $safeitemname$(System.Collections.Generic.Dictionary<string, string> keywords) : base(keywords) { }
        public $safeitemname$(System.Exception innerException) : base(innerException) { }
        public $safeitemname$(System.Collections.Generic.Dictionary<string, string> keywords, System.Exception innerException) : base(keywords, innerException) { }
    }
}
