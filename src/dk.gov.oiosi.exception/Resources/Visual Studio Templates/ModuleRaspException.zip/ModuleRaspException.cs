using System;
using System.Collections.Generic;
using System.Text;
using System.Resources;

using Oiosi.Rasp.ExceptionHandling;

namespace $rootnamespace$
{
    public class $safeitemname$ : Oiosi.Rasp.ExceptionHandling.MainException {
        
        private static ResourceManager resourceManager = new ResourceManager(typeof(ErrorMessages));
        
        public $safeitemname$() : base(resourceManager) { }
        public $safeitemname$(System.Collections.Generic.Dictionary<string, string> keywords) : base(resourceManager, keywords) { }
        public $safeitemname$(System.Exception innerException) : base(resourceManager, innerException) { }
        public $safeitemname$(System.Collections.Generic.Dictionary<string, string> keywords, System.Exception innerException) : base(resourceManager, keywords, innerException) { }
    }
}
